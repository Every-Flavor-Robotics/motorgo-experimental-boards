#ifndef _HTTP_Method_H_
#define _HTTP_Method_H_

#include "http_parser.h"

typedef enum http_method HTTPMethod;
#define HTTP_ANY (HTTPMethod)(255)

#endif /* _HTTP_Method_H_ */
