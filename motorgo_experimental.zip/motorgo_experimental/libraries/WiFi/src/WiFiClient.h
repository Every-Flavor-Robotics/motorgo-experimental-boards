#pragma once
#include "NetworkClient.h"
typedef NetworkClient WiFiClient;
