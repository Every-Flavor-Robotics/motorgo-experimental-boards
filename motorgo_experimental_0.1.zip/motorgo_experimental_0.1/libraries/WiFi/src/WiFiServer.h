#pragma once
#include "NetworkServer.h"
typedef NetworkServer WiFiServer;
